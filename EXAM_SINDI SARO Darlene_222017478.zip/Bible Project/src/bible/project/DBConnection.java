/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bible.project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Christian
 */
// Class for managing database connections
public class DBConnection {
  // Static variables for storing database connection details
  static final String DB_URL="jdbc:mysql://localhost/bible project"; // Database URL
   static final String USER = "root";     // Database username
   static final String PASS = "";        // Database password (ideally should be retrieved securely)
   
   // Method to establish a connection to the database
   public static Connection DBconnection(){
  
   Connection con= null;
       try {
           // Attempt to create a connection using the provided credentials
           con=DriverManager.getConnection(DB_URL, USER, PASS);
           return con; // Return the connection object if successful
       } catch (SQLException ex) {
           // Handle any SQL exceptions
           System.out.println("BYANZE PEE");   // Replace with a more informative error message      
       }
        return null;  // Return null if connection fails
   }  
}

